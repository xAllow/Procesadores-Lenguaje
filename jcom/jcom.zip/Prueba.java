import java.io.*;
/** Clase principal */
class Prueba {
 /** Medodo main */
 public static void main(String argv[]) {
 /*
 Aqui va el codigo
 */
 }
} // class